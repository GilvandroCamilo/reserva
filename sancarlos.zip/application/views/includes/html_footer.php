	<footer class="desktop">
			<p>© SanCarlos FM Campinas 87,9 -  Todos os direitos reservados</p>
			<img class="desktop" src="<?= base_url(); ?>assets/img/miniLogo.png">
	</footer>
</div>
</body>
</html>