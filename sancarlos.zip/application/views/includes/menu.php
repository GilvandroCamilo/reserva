<nav>
		<span  id="side" class="material-icons" style="font-size: 100px; cursor:pointer;" onclick="openNav()">menu</span>
		<button id="ouca" class="btn btn-primary btn-lg">Ouça ao Vivo</button>
		<img class="desktop shake-vertical-slow shake-constant" src="<?= base_url(); ?>assets/img/miniLogo.png">
		<small class="desktop">
		<p>Tocando agora:</p>
		<p>A VOZ DO BRASIL</p>
		</small>
	</nav>
	
