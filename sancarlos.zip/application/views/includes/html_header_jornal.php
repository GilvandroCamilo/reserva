<!DOCTYPE html>
<html>
<head>
	<title>San Carlos FM</title>
	<link rel="stylesheet" type="text/css" href="http://csshake.surge.sh/csshake.min.css">
	<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/fonts/fonts.css">
	<link rel="stylesheet" type="text/css" href="css/icon-google.css">
	<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Archivo+Narrow:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/normalize.css">
	<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/estiloJornal.css">
	
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="user-scalable=no">
</head>