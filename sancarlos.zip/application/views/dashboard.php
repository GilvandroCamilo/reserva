
<body id="body">
	<header>
		  <nav id="menu" class="menu">
			<a onclick="sessoes(0)">Início</a>
			<a onclick="sessoes(0)" href="<?=base_url()?>dashboard/jornal">Jornal <!-- <i class="fa fa-newspaper-o" aria-hidden="true"></i> --></a>
			<a class="clickMenu" onclick="subMenu(0)">Sobre</a>
			<div class="menuSuspenso sobre">
			<a id="linkMenu" onclick="sessoes(5)">Fotos</a>
			<a id="linkMenu" onclick="sessoes(6)">Equipe</a>
			</div>
			<a class="clickMenu" onclick="subMenu(1)">Radio</a>
			<i class="baixo"></i>
			<div class="menuSuspenso radio">
			<a id="linkMenu" onclick="openNav()">Promoções</a>
			<a id="linkMenu" onclick="sessoes(1)">Programação</a>
			<a id="linkMenu" onclick="openNav()">Eventos</a>
			<a id="linkMenu" onclick="openNav()">Vídeos</a>
			</div>
			<a class="clickMenu" onclick="subMenu(2)">Anuncie</a>
			<div class="menuSuspenso anuncie">		
			<a id="linkMenu" onclick="openNav()">Contato</a>
			<a id="linkMenu" onclick="openNav()">Política De Privacidade</a>			
			</div>

			<div class="icones">
			<i class="fa fa-facebook-f"></i>
			<i class="fa fa-twitter"></i>
			<i class="fa fa-google-plus-square"></i>
			</div>
			<input id="pesquisar" type="text" name="">
		</nav>
		<img id="logo" class="inicio" src="<?= base_url(); ?>assets/img/logo-azul.png">
	</header>
	
	<div id="main">
		
	<section  class="inicio" id="jornal">
				<div class="meuSlides fade">
			<img src="<?= $noticia[0]->imagem1; ?>">
			
			<p><?= $noticia[0]->resumo1; ?></p>
			
		</div>
		<div class="meuSlides fade">
		  	<img src="<?= $noticia[0]->imagem2; ?>">

		  <p><?= $noticia[0]->resumo2; ?></p>
		 
		</div>
		<div class="meuSlides fade">
			<img src="<?= $noticia[0]->imagem3; ?>">
		  
		  <p><?= $noticia[0]->resumo3; ?></p>
		  
		</div>
	</section>
	<section class="programacao sessao">
		<div>
		<i class="esquerda"></i>
		<h1>DOMINGO</h1>
		<i class="direita"></i>
		</div>
		<ul id="lista">
			<li id="0" onclick="programacao(this.id)" ><p>10:30</p>Tarde Sertanejo<i class="baixo"></i>
				<img src="<?= base_url(); ?>assets/img/tardeSertaneja.jpg"></li>
			<li id="1" onclick="programacao(this.id)" ><p>15:30</p>Noite Do Rock <i class="baixo"></i><img src="<?= base_url(); ?>assets/img/noiteDoRock.jpg"></li>
			<li id="2" onclick="programacao(this.id)"><p id="aoVivo">No Ar</p>Notícias da Manhã<i class="baixo"></i><img src="<?= base_url(); ?>assets/img/boletim-noticias.jpg"></li>
			<li id="3" onclick="programacao(this.id)"><p>17:30</p>Hora do Esporte<i class="baixo"></i><img src="<?= base_url(); ?>assets/img/horadoesporte.jpg"></li>
			<li id="4" onclick="programacao(this.id)"><p>09:30</p>Musicas Tocantinenses<i class="baixo"></i><img src="<?= base_url(); ?>assets/img/tardeSertaneja.jpg"></li>
			<li id="5" onclick="programacao(this.id)"><p>10:30</p>De Olho na Radio<i class="baixo"></i><img src="<?= base_url(); ?>assets/img/tardeSertaneja.jpg"></li>
			<li id="6" onclick="programacao(this.id)"><p>10:30</p>Entrevistas<i class="baixo"></i><img src="<?= base_url(); ?>assets/img/tardeSertaneja.jpg"></li>
			<li id="7" onclick="programacao(this.id)"><p>10:30</p>Momento da Piada<i class="baixo"></i><img src="<?= base_url(); ?>assets/img/tardeSertaneja.jpg"></li>
			<li id="8" onclick="programacao(this.id)"><p>10:30</p>Mais Noticias<i class="baixo"></i><img src="<?= base_url(); ?>assets/img/tardeSertaneja.jpg"></li>
		</ul>
	</section>
	<section style="display: none" class="programacaoDesktop">
		<div>
			<img src="img/horadoesporte.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/horadoesporte.jpg">
			<img src="img/tardeSertaneja.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
		</div>
	</section>
	<br>
	<section class="sessao recados">
		<h1>MURAL DE RECADOS</h1>
		
		<button><span>Deixe Seu recado</span></button>
		
		<div class="recado">
			<div>
			<img src="<?= base_url(); ?>assets/img/recado.png">
			<p id="nome">João Ferreira</p>
			</div>
			<p>Bem informativa, gostei!</p>
		</div>
		<div class="recado">
			<div>
			<img src="<?= base_url(); ?>assets/img/recado.png">
			<p id="nome">João Ferreira</p>
			</div>
			<p>Bem informativa, gostei!</p>
		</div>
		<div class="recado">
			<div>
			<img src="<?= base_url(); ?>assets/img/recado.png">
			<p id="nome">João Ferreira</p>
			</div>
			<p>Bem informativa, gostei!</p>
		</div>
	</section>
	
	<section class="sessao promocao">
		<h1>PROMOÇÕES</h1>
		<img src="<?= base_url(); ?>assets/img/promocao.jpg">
	</section>

	<section class="sessao facebook">
		<h1>CURTA NO FACEBOOK</h1>
	</section>
	<section class="fotos sessao">
		<h1 class="clica">FOTOS</h1>
		<img id="testa" src="<?= base_url(); ?>assets/img/fotos.jpg">
		<img src="<?= base_url(); ?>assets/img/fotos1.jpg">
		<img src="<?= base_url(); ?>assets/img/fotos2.jpg">
		<img src="<?= base_url(); ?>assets/img/fotos3.jpg">
		<img src="<?= base_url(); ?>assets/img/fotos.jpg">
		<img src="<?= base_url(); ?>assets/img/fotos1.jpg">
	</section>

	<section class="equipe sessao">
		<h1>EQUIPE</h1>
		<img src="<?= base_url(); ?>assets/img/pessoa1.png">
		<!-- <p>Pessoa Um</p>
		 --><img src="<?= base_url(); ?>assets/img/pessoa2.png">
		<!-- <p>Pessoa Dois</p>
 -->		<img src="<?= base_url(); ?>assets/img/pessoa3.png">
		<!-- <p>Pessoa Três</p>
 -->		<img src="<?= base_url(); ?>assets/img/pessoa4.png">
		<!-- <p>Pessoa Quatro</p -->
		<img src="<?= base_url(); ?>assets/img/pessoa5.png">
		<!-- <p>Pessoa Cinco</p> -->
		<img src="<?= base_url(); ?>assets/img/pessoa6.png">
	<p id="sobre">Aqui fica o texto da Equipe, somos a mais nova rádio de notícias da capital, o se portal de notícias, aqui é o texto sobre Equipe
		aqui é o texto sobre Equipe aqui é o texto sobre Equipe aqui é o texto sobre Equipe aqui é o texto sobre Equipe aqui é o texto sobre Equipe 
		aqui é o texto sobre Equipe aqui é o texto sobre Equipe aqui é o texto sobre Equipe aqui é o texto sobre Equipe aqui é o texto sobre Equipe 
	</p>
	</section>
	

		<section class="sessao vemAi">
		<h1>As Mais Pedidas</h1>
	</section>
		<script type="text/javascript" src="<?= base_url(); ?>assets/js/animate.js"></script>

