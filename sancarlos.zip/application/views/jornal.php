<form action="<?=base_url()?>dashboard/escolher_jornal" method="post">
<div>
	<input type="date" id="dataJornal" value="<?= $noticia[0]->data?>" name="dataJornal" >
	<button type="submit">Selecionar Data</button>
</div>
<a href="<?= $noticia[0]->pdf; ?>">
	<img id="pdf" src="<?= $noticia[0]->imagem1; ?>" ></img>
</a>
</form>