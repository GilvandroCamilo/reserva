<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */


    public function verificar_sessao(){
        if ($this->session->userdata('logado') == false) {
            redirect('dashboard/login');
        }
    }
	public function index(){
		
		$maior_id = mysql_result(mysql_query("SELECT MAX(idNoticia) FROM noticia"), 0);
		$this->db->where('idNoticia',$maior_id);
		$dados['noticia'] = $this->db->get('noticia')->result();
		$dados['programacao'] = $this->db->get('programacao')->result();
		$dados['fotos'] = $this->db->get('fotos')->result();
		$dados['promocoes'] = $this->db->get('promocoes')->result();
		$dados['equipe'] = $this->db->get('equipe')->result();

		




		
$result = array();
$tamanhoPro = sizeof($dados['programacao']);
		for ($i = 0; $i <= 0; $i++) {
	array_push($result, $dados['programacao'][$i]->horario);
}
sort($result);
for($j = 0; $j<=0; $j++){
	$dados['programacao'][$j]->horario = $result[$j];
}


		$this->load->view('includes/html_header');
		$this->load->view('includes/menu');
		$this->load->view('dashboard',$dados);
		$this->load->view('includes/html_footer');
	}
	
	public function jornal(){
		$maior_id = mysql_result(mysql_query("SELECT MAX(idNoticia) FROM noticia"), 0);
		$this->db->where('idNoticia',$maior_id);
		$dados['noticia'] = $this->db->get('noticia')->result();
		$dados['noticia'][0]->semJornal = "";

		$this->load->view('includes/html_header');
		$this->load->view('includes/menu');
		$this->load->view('jornal',$dados);
		$this->load->view('includes/html_footer');

	}
	public function escolher_jornal(){
		$maior_id = mysql_result(mysql_query("SELECT MAX(idNoticia) FROM noticia"), 0);
		$dia = $this->input->post('dataJornal');
		$this->db->where('data',$dia);
		$dados['noticia'] = $this->db->get('noticia')->result();
		if (sizeof($dados['noticia']) == 0){
			$this->db->where('idNoticia',$maior_id);
			$dados['noticia'] = $this->db->get('noticia')->result();
			$semJornal = "Não há jornais nessa data";
		}
		$this->load->view('includes/html_header');
		$this->load->view('includes/menu');
		$this->load->view('jornal',$dados);
		$this->load->view('includes/html_footer');
	}





	public function logar(){
		$email = $this->input->post('email');
		$senha = md5($this->input->post('senha'));

		$this->db->where('senha',$senha);
		$this->db->where('email',$email);
		$this->db->where('status',1);	
		$data['usuario'] = $this->db->get('usuario')->result();

		if (count($data['usuario'])==1) {
			$dados['nome'] = $data['usuario'][0]->nome;
			$dados['id'] = $data['usuario'][0]->idUsuario;
			$dados['logado'] = true;
			$this->session->set_userdata($dados);
			redirect('dashboard');
		}else{
			redirect('dashboard/login');
		}
	}




}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */