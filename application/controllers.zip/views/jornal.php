<style type="text/css">
@media screen and (min-width: 1000px) {
	#nav1{
		z-index: -1;
	}
	.menu{
		margin-top: -150px;	
		float: right;
		margin-left: 20%;
		width: 65%;
		z-index: 1;
	}
	.privacidade{
		display: none;
	}
	.logo{
		float: left;
	}
}	

</style>
<link rel="stylesheet" type="text/css" href="<?= base_url()?>assets/css/estiloJornal.css">
<form action="<?=base_url()?>dashboard/escolher_jornal" method="post">
<div>
	<div id="calendar"></div>
	<input type="date" id="dataJornal" value="<?= $noticia[0]->data?>" name="dataJornal" >
	<button id="selecData" type="submit">Selecionar Data</button>
</div>
<a href="<?= $noticia[0]->pdf; ?>">
	<img id="pdf" alt="não há jornais nessa data" src="<?= $noticia[0]->imagem1; ?>" ></img>
</a>

</form>

<script type="text/javascript">
    // $('#calendar').datepicker({
    // language: "pt-BR",
    // calendarWeeks: true,
    // todayHighlight: true
    // });
    </script>
<script type="text/javascript">
	// var windowWidth = window.innerWidth;
	// if (windowWidth > 1000) {
	// 	document.getElementsByClassName('menu')[0].style.display = "none";
	// 	document.getElementById('logo').style.display = 'none';
	// }else{
	// 	// document.getElementById('menu')
	// 	document.getElementById('logo').style.display = 'none';
	// }

	// document.getElementById("inicioBotao").style.display = "block";
</script>