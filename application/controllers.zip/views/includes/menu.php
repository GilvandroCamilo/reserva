<nav id="nav1">
		<span  id="side" class="material-icons" style="font-size: 100px; cursor:pointer;" onclick="openNav()">menu</span>
		<button id="ouca" class="btn btn-primary btn-lg">Ouça ao Vivo</button>
		<img class="desktop shake-vertical-slow shake-constant" src="<?= base_url(); ?>assets/img/miniLogo.png">
		<small class="desktop">
		<p>Tocando agora:</p>
		<p>A VOZ DO BRASIL</p>
		</small>
		<a id="inicioBotao" href="http://localhost/sancarlos/">Início</a>
		<!-- <div class="icones">
			<i class="fa fa-facebook-f"></i>
			<i class="fa fa-twitter"></i>
			<i class="fa fa-google-plus-square"></i>
			</div> -->
	</nav>

		<header>
		  <nav id="desktop" class="menu">
			<a href="<?=base_url()?>" >Início</a>
			<a onclick="sessoes(0)" href="<?=base_url()?>dashboard/escolher_jornal">Jornal <!-- <i class="fa fa-newspaper-o" aria-hidden="true"></i> --></a>
			<!-- <a class="clickMenu" onclick="subMenu(0)">Sobre</a> -->
			
			<a id="linkMenu" href="#fotos">Fotos/Equipe</a>
			<!-- <a id="linkMenu" onclick="sessoes(6)">Equipe</a> -->
			
			<a class="clickMenu" onclick="subMenu(1)">Radio</a>
			
			
			<a id="linkMenu" onclick="openNav()">Promoções/Programação</a>
			<!-- <a id="linkMenu" onclick="sessoes(1)">Programação</a> -->
			<!-- <a id="linkMenu" onclick="openNav()">Eventos</a>
			<a id="linkMenu" onclick="openNav()">Vídeos</a> -->
			
			<a class="clickMenu" onclick="subMenu(2)">Anuncie/Contato</a>
			<a id="linkMenu" class="privacidade" onclick="openNav()">Política De Privacidade</a>			
			

			<!-- <div class="icones">
			<i class="fa fa-facebook-f"></i>
			<i class="fa fa-twitter"></i>
			<i class="fa fa-google-plus-square"></i> -->
			<!-- </div> -->
			<!-- <input id="pesquisar" type="text" name=""> -->
		</nav>
		<nav id="celular" class="menu">
			<a href="<?=base_url()?>">Início</a>
			<a onclick="sessoes(0)" href="<?=base_url()?>dashboard/escolher_jornal">Jornal <!-- <i class="fa fa-newspaper-o" aria-hidden="true"></i> --></a>
			<a class="clickMenu" onclick="subMenu(0)">Sobre</a>
			<div class="menuSuspenso sobre">
			<a id="linkMenu" onclick="sessoes(5)">Fotos</a>
			<a id="linkMenu" onclick="sessoes(6)">Equipe</a>
			</div>
			<a class="clickMenu" onclick="subMenu(1)">Radio</a>
			<i class="baixo"></i>
			<div class="menuSuspenso radio">
			<a id="linkMenu" onclick="openNav()">Promoções</a>
			<a id="linkMenu" onclick="sessoes(1)">Programação</a>
			<!-- <a id="linkMenu" onclick="openNav()">Eventos</a> -->
			<!-- <a id="linkMenu" onclick="openNav()">Vídeos</a> -->
			</div>
			<a class="clickMenu" onclick="subMenu(2)">Anuncie</a>
			<div class="menuSuspenso anuncie">		
			<a id="linkMenu" onclick="openNav()">Contato</a>
			<a id="linkMenu" onclick="openNav()">Política De Privacidade</a>			
			</div>

			<div class="icones">
			<a class="contato" href=""><i class="fa fa-facebook-f"></i></a>
			<a class="contato" href=""><i class="fa fa-twitter"></i></a>
			<a class="contato" href=""><i class="fa fa-google-plus-square"></i></a>
			<a class="contato" style="border-style: none;" href="tel:6395555555"><i  class="fa fa-phone"></i></a>
			<a class="contato" href=""><i class="fa fa-whatsapp" ></i></a>
			<a class="contato" style="border-style: none;"  href="mailto:contato@radiosancarlos.com.br"><i  class="fa fa-envelope-square"></i>
			</a>
			</div>
			<input id="pesquisar" type="text" name="">
		</nav>
		<img id="logo" class="inicio" src="<?= base_url(); ?>assets/img/logo-azul.png">
	</header>
	<script type="text/javascript">
		// var node = document.getElementById("sobre");
		// 	node.parentNode.removeChild(node);
	</script>
	
