<!DOCTYPE html>
<html>
<head>
	<title>San Carlos FM</title>
<!-- 	<link rel="stylesheet" type="text/css" href="http://csshake.surge.sh/csshake.min.css"> -->
	<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/fonts/fonts.css">
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/css/icon-google.css">
	<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Archivo+Narrow:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/normalize.css">
	<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/estiloJornal.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.min.js"></script>
<script src="<?=base_url()?>assets/js/datepickerPt-BR.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.standalone.min.css" rel="stylesheet"/>
	
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="user-scalable=no">
</head>