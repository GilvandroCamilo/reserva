
<body id="body">

	
	<div id="main">
		
	<section class="inicio" id="jornal">
		<a href="dashboard/escolher_jornal">
				<div class="meuSlides fade">
			<img src="<?= $noticia[0]->imagem1; ?>">
			
			<p><?= $noticia[0]->resumo1; ?></p>
			
		</div>
		<div class="meuSlides fade">
		  	<img src="<?= $noticia[0]->imagem2; ?>">

		  <p><?= $noticia[0]->resumo2; ?></p>
		 
		</div>
		<div class="meuSlides fade">
			<img src="<?= $noticia[0]->imagem3; ?>">
		  
		  <p><?= $noticia[0]->resumo3; ?></p>
		  
		</div>
		</a>
	</section>
	<section class="programacao sessao">
		<div>
		<i class="esquerda" onclick="getDay( parseInt(this.id)-1)"></i>
		<h1 class="diaTitulo">DOMINGO</h1>
		<i class="direita" onclick="getDay( parseInt(this.id)+1)"></i>
		</div>
		<ul id="lista">
			<?php foreach($programacao as $program){ ?>
			<li id="list<?= $program->idProgramacao;?>" class="semanaDia <?=$program->dia?>" onclick="programacao(this.id)" ><p><?=$program->horario?></p><?=$program->programa?><i class="baixo"></i>
				<img src="<?=$program->imagem;?>"></li>
			<?php } ?>
		</ul>
	</section>
	<section style="display: none" class="programacaoDesktop">
		<div>
			<img src="img/horadoesporte.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/horadoesporte.jpg">
			<img src="img/tardeSertaneja.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
			<img src="img/boletim-noticias.jpg">
		</div>
	</section>
	<br>
	<section class="sessao recados">
		<h1>MURAL DE RECADOS</h1>
		
		<button><span>Deixe Seu recado</span></button>
		
		<div class="recado">
			<div>
			<img src="<?= base_url(); ?>assets/img/recado.png">
			<p id="nome">João Ferreira</p>
			</div>
			<p>Bem informativa, gostei!</p>
		</div>
		<div class="recado">
			<div>
			<img src="<?= base_url(); ?>assets/img/recado.png">
			<p id="nome">João Ferreira</p>
			</div>
			<p>Bem informativa, gostei!</p>
		</div>
		<div class="recado">
			<div>
			<img src="<?= base_url(); ?>assets/img/recado.png">
			<p id="nome">João Ferreira</p>
			</div>
			<p>Bem informativa, gostei!</p>
		</div>
	</section>
	
	<section class="sessao promocao">
		<h1>PROMOÇÕES</h1>
		<?php foreach($promocoes as $promo){ ?>
		<img src="<?= $promo->img?>">
		<?php } ?>
	</section>

	<section class="sessao facebook">
		<h1>CURTA NO FACEBOOK</h1>
	</section>
	<section id="fotos" class="fotos sessao">
		<h1 class="clica">FOTOS</h1>
		<?php foreach($fotos as $fot){?>
		<img id="testa" src="<?=$fot->img ?>">
		<?php } ?>
	</section>

	<section class="equipe sessao">
		<h1>EQUIPE</h1>
		<?php foreach ($equipe as $equ) { ?>

		<img src="<?= $equ->img ?>">
		<!-- <p>Pessoa Um</p>
		 -->
		 <?php } ?>
	<p id="sobre">Aqui fica o texto da Equipe, somos a mais nova rádio de notícias da capital, o se portal de notícias, aqui é o texto sobre Equipe
		aqui é o texto sobre Equipe aqui é o texto sobre Equipe aqui é o texto sobre Equipe aqui é o texto sobre Equipe aqui é o texto sobre Equipe 
		aqui é o texto sobre Equipe aqui é o texto sobre Equipe aqui é o texto sobre Equipe aqui é o texto sobre Equipe aqui é o texto sobre Equipe 
	</p>
	</section>
	

		<section class="sessao vemAi">
		<h1>As Mais Pedidas</h1>
	</section>
	
		

